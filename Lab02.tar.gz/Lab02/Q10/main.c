extern void lab02c(long long int a);

int main(void)
{
    lab02c(54);
    return 0;
}
