extern long long int test();
extern long long int lab02b();

int main(void)
{
	//test();
	lab02b();
    return 0;
}
