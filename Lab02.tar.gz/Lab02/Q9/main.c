
extern long long int lab02b();

int main(void)
{
	lab02b();
    return 0;
}
