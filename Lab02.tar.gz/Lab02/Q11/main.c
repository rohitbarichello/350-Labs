#include <stdio.h>

extern long long int lab02d(long long int a);

int main(void)
{
    printf("Result is = %d\n", lab02d(10));
    return 0;
} 

